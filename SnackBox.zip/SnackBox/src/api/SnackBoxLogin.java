package api;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.derby.tools.sysinfo;
import org.json.JSONObject;

import com.mongodb.util.JSON;

import Bean.CartBean;
import Bean.DetailsBean;
import Bean.MenuList;
import Dao.DetailsDao;
import Resources.JSONParser;

@Path("SnackBoxLogin")
public class SnackBoxLogin {
	@Path("det/{name1}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response returnPassword(@PathParam("name1") String name)
	{
		System.out.println("ksga");
		String usr=name;
		System.out.println("Username: "+usr);
		Response result = null;
		DetailsDao db = new DetailsDao();
		List<String> pwd= db.returnPwd(usr);
		//DetailsBean d=new DetailsBean();
		//d.setUsername(pwd.get(0));
		//d.setPassword(pwd.get(1));
			System.out.println(pwd.get(1));
		String employeeJson = JSONParser.beanToJson(pwd);

		// Sends the response as JSON string
		result = Response.ok(employeeJson).build();
		System.out.println(result);
		return result;
	}
	
	@Path("menu")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getFoodMenu()
	{
		System.out.println("Inside getFoodMenu");
		List<MenuList> menuList= new ArrayList<MenuList>();
		Response result = null;
		DetailsDao db = new DetailsDao();
		menuList= db.getFoodMenu();
		System.out.println("Menu in api: "+menuList.get(0).getName());
		String menu = JSONParser.beanToJson(menuList);
		result = Response.ok().entity(menu).build();
		return result;
	}
	
	
	@Path("addtocart")
	@POST
	@Produces(MediaType.TEXT_HTML)
	@Consumes(MediaType.APPLICATION_JSON)
	public String postFoodDetails(String foodList)
	{
		System.out.println("Inside postFoodDetails in api");
		System.out.println("String foodlist: "+foodList);
		//System.out.println(JSON.parse(foodList));
		JSONObject jsonObj = new JSONObject(foodList);
		/*System.out.println(jsonObj.get("qd"));
		System.out.println(jsonObj.get("fd"));
		JSONObject foodobj= jsonObj.getJSONObject("fd");
		System.out.println(foodobj.getString("name"));*/
		//System.out.println("Inside getFoodMenu" + jsonObj.getString("name"));
		//List<MenuList> menuList= new ArrayList<MenuList>();
		Response result = null;
		DetailsDao db = new DetailsDao();
		String msg=db.postFoodDetails(jsonObj);
		System.out.println(msg);
		//System.out.println("Menu in api: "+menuList.get(0).getName());
		//String menu = JSONParser.beanToJson(msg);
		//result = Response.ok().entity(msg).build();
		return msg;
	}
	
	
	@Path("cartItems/{user}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getCartItems(@PathParam("user") String user)
	{
		System.out.println("Inside getCartItems");
		List<CartBean> cartList= new ArrayList<CartBean>();
		Response result = null;
		DetailsDao db = new DetailsDao();
		cartList= db.getCartItems(user);
		
		for(CartBean cb: cartList)
		{
			cb.settPrice(cb.getPrice()*cb.getQuantity());
		}
		
		System.out.println("Menu in api: "+cartList.get(0).getName());
		//String menu1 = JSONParser.beanToJson(cartList);
		result = Response.ok().entity(cartList).build();
		System.out.println("returning"+result);
		return result;
	}
	
	
		@POST
		@Path("delcartItems")
		@Produces(MediaType.TEXT_HTML)
		public String deleteCartItems( String food) {
			String message = null;
			Response result = null;
			System.out.println("inside delete");
			JSONObject jsonObj = new JSONObject(food);
			
			System.out.println(jsonObj.getString("name"));
			DetailsDao db = new DetailsDao();
			String msg=db.deleteCartItems(jsonObj);
			System.out.println(msg);
			return msg;
	 }
	
}
