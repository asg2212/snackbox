package Dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.derby.tools.sysinfo;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.json.JSONObject;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.Mongo;

import Bean.CartBean;
import Bean.DetailsBean;
import Bean.MenuList;
import Entity.DetailsEntity;
import Resources.HibernateUtil;

public class DetailsDao {

	List<String> details =new ArrayList<String>();
	public List<String> returnPwd(String username)
	{
		
		try
		{	
			System.out.println(username);
			String name1=username.replace("\"", "");
			System.out.println(name1);
			 Mongo mongoClient = new Mongo( "localhost" , 27017 );
			 DB db = mongoClient.getDB( "snackbox" );
	         System.out.println("Connect to database successfully");
	         DBCollection coll=db.getCollection("details");
	         BasicDBObject searchQuery = new BasicDBObject();
	         searchQuery.put("username",name1);
	         DBCursor cursor = coll.find(searchQuery);

	         while (cursor.hasNext()) {
	        	 DBObject a=cursor.next();
	        	
	        	 String uname=(String)a.get("username");
	        	 String password=(String)a.get("password");
	        	 System.out.println(uname);
	        	 
	        	 details.add(uname);
	        	 details.add(password);
		         
	        }
	       
	        
		}
		catch(Exception e)
		{
			System.out.println(e);
		}

		return details;
	}
	
	public List<MenuList> getFoodMenu()
	{
		System.out.println("Inside Dao function: getFoodMenu");
		List<MenuList> menu= new ArrayList<MenuList>();
		try
		{
			Mongo mongoClient = new Mongo( "localhost" , 27017 );
			 DB db = mongoClient.getDB( "snackbox" );
	         System.out.println("Connect to database successfully");
	         DBCollection coll=db.getCollection("menu");
	        
	         DBCursor cursor = coll.find();
	         int count = 0;
	         
	         while(cursor.hasNext()) {
	        	 DBObject a=cursor.next();
	             //System.out.println(cursor.next());
	             MenuList m= new MenuList();
	             
	             m.setName((String)a.get("name"));
	             m.setPrice((Double)a.get("price"));
	             System.out.println(count);
	             count++;
	             menu.add(m);
	         }
	         
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return menu;
	}
	
	
	public String postFoodDetails(JSONObject jsonObj)
	{
		String msg="";
		try
		{
			Mongo mongoClient = new Mongo( "localhost" , 27017 );
			 DB db = mongoClient.getDB( "snackbox" );
	         System.out.println("Connect to database successfully");
	         DBCollection coll=db.getCollection("foodCart");
	         BasicDBObject document = new BasicDBObject();
	        String fname=jsonObj.getString("name");
	        System.out.println(fname);
	        DBCursor cursor = coll.find();
	        boolean insert=false;
	        while(cursor.hasNext())
	        {
	        	DBObject a=cursor.next();
	      
	        	if(fname.equals(a.get("name")))
	        	{
	        		System.out.println("inside if");
	        		int q= (Integer)a.get("quantity");
	        		int tq= q + jsonObj.getInt("quantity");
	    	     	BasicDBObject searchQuery = new BasicDBObject().append("name", fname);
	    	     	BasicDBObject newDocument = new BasicDBObject();
	    	     	newDocument.put("username", jsonObj.getString("username"));
	    	     	newDocument.put("name", jsonObj.getString("name"));
	    	     	newDocument.put("price", jsonObj.getDouble("price"));
	    	    	newDocument.put("quantity", tq);
	    	    	coll.update(searchQuery, newDocument);
	    	    	System.out.println("updated successfully");
	    	    	insert=true;
	        		 
	        	}
	        }
	        if(insert==false)
	        {
	        	document.put("username", jsonObj.getString("username"));
	        	document.put("name", jsonObj.getString("name"));
		     	document.put("price", jsonObj.getDouble("price"));
		     	document.put("quantity", jsonObj.getInt("quantity"));
		     	coll.insert(document);
	        }
	     	System.out.println("inserted successfully");
	     	 msg="Added successfully";
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return msg;
	}
	
	public List<CartBean> getCartItems(String user)
	{
		System.out.println("Inside Dao function: getCartItems");
		List<CartBean> cart= new ArrayList<CartBean>();
		try
		{
			Mongo mongoClient = new Mongo( "localhost" , 27017 );
			 DB db = mongoClient.getDB( "snackbox" );
	         System.out.println("Connect to database successfully");
	         DBCollection coll=db.getCollection("foodCart");
	         String name1=user.replace("\"", "");
	         System.out.println(name1);
	         BasicDBObject searchQuery = new BasicDBObject();
	         searchQuery.put("username", name1);
	         DBCursor cursor = coll.find(searchQuery);
	         
	         while(cursor.hasNext()) {
	        	 DBObject a=cursor.next();
	             //System.out.println(cursor.next());
	             CartBean cb= new CartBean();
	             
	             cb.setName((String)a.get("name"));
	             cb.setPrice((Double)a.get("price"));
	             
	             //System.out.println(a.get("quantity"));
	           cb.setQuantity((Integer)a.get("quantity"));
	             cb.settPrice(0D);
	             cart.add(cb);
	         }
	         
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return cart;
	}
	
	
	
	public String deleteCartItems(JSONObject jsonObj)
	{
		System.out.println("Inside Dao function: deleteCartItems");
		//List<CartBean> cart= new ArrayList<CartBean>();
		String msg="";
		try
		{
			Mongo mongoClient = new Mongo( "localhost" , 27017 );
			 DB db = mongoClient.getDB( "snackbox" );
	         System.out.println("Connect to database successfully");
	         DBCollection coll=db.getCollection("foodCart");
	        
	         
	         String foodName = jsonObj.getString("name");
	         String user = jsonObj.getString("user");
	         BasicDBObject searchQuery = new BasicDBObject();
	         searchQuery.put("name", foodName);
	         searchQuery.put("username", user);
	        // DBCursor cursor = coll.find(searchQuery);
	         int count = 0;
	         coll.remove(searchQuery);	
	          msg="deleted successfully";
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return msg;
	}
	
	}
	

