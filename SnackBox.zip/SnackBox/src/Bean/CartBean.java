package Bean;

public class CartBean {

	
	private String username;
	private String name;
	private Integer quantity;
	private double price;
	private double tPrice;
	public double gettPrice() {
		return tPrice;
	}
	public void settPrice(double tPrice) {
		this.tPrice = tPrice;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
}
