
package Resources;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import Entity.DetailsEntity;

public class HibernateUtil {
	
	private static final SessionFactory sessionfactory ;
	
	static
	{
		try
		{
			System.out.println("ashkl");
			Configuration cfg = new AnnotationConfiguration().configure().addAnnotatedClass(DetailsEntity.class);
			//Configuration cfg =new Configuration().configure("../src/Resources/hibernate.cfg.xml");
			ServiceRegistry service = new ServiceRegistryBuilder().applySettings(cfg.getProperties()).buildServiceRegistry();
			System.out.println(cfg.getProperty("hibernate.connection.password"));
			sessionfactory = cfg.buildSessionFactory(service);
		}
		catch(Throwable e)
		{
			System.err.println("error"+ e);
			throw new ExceptionInInitializerError(e);
		}
	}
	
	public static SessionFactory getSessionFactory()
	{
		System.out.println("in session fac");
		return sessionfactory;
	}
}
