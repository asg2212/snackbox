var app= angular.module("app",["ngRoute"]);



app.config(['$routeProvider',
    function($routeProvider) {
        $routeProvider.
        when('/login', {
            templateUrl: 'login.html',
            controller :'loginctrl'
        }).
        when('/Home', {
            templateUrl: 'Home.html',
            //controller :'HomeController'
        }).
        when('/menuPage', {
            templateUrl: 'menuPage.html',
            controller :'menuCtrl'
        }).
        when('/cartPage', {
            templateUrl: 'cartPage.html',
            controller :'menuCtrl'
        }).
        when('/logout', {
            templateUrl: 'Logout.html',
            controller :'logoutCtrl'
        }).
        when('/orderPage', {
            templateUrl: 'orderPage.html',
            //controller :'HomeController'
        }).
        otherwise({
            redirectTo: 'Home.html'
        });
    }]);

app.controller('loginctrl',function($location,$scope, $http,$rootScope)
		{
			$scope.user={};
			$scope.username=null;
			$scope.password=null;
			
			$rootScope.userName = null;
			
			$rootScope.loggedIn=false;
			/*alert($rootScope.loggedIn);*/
			$scope.submit=function()	
			{	
				//alert($scope.username);
				var data = angular.toJson($scope.username);
				$http.get("http://localhost:8000/SnackBox/api/SnackBoxLogin/det/"+data).
				then(function(response)
						{	
						
						 $scope.user= response.data;
						// alert("hiihihi" + $scope.user[1]+$scope.user);
						if($scope.password == $scope.user[1])
							{
								$scope.msg= true;
								$rootScope.userName=$scope.user[0];
								$rootScope.loggedIn=true;
								$location.path("/Home");
							}
						else
							{
								$scope.msg= false;
							}
						},function(response)
						{
							$scope.message = response.data.message;
						});
				}
			
		});

app.controller('logoutCtrl',function($location,$scope, $http,$rootScope)
		{
			$rootScope.userName=null;
			$rootScope.loggedIn=false;
		});


app.controller('menuCtrl',function($location,$scope, $http,$rootScope,$route)
		{
	
			$scope.foodName = null;
			$scope.price = null;
			$scope.foodCart = {name:null,quantity:null, price:null};
			$scope.foodList=[{name:null, price:null},
					{name:null, price:null},
					{name:null, price:null},
					{name:null, price:null}];
			$scope.cartItems=[];
			$scope.foods={name:null,user:null};
			$scope.message = null;
			
			$scope.fetchMenu= function()
			{
				
				$http.get("http://localhost:8000/SnackBox/api/SnackBoxLogin/menu")
				.then(function(response){
					
					//var food=JSON.stringify($scope.foodList[0]);
					//alert(response.data[0].name+response.data.length);
					for(var i = 0 ; i<response.data.length;i++)
						{
							  $scope.foodList[i].name=response.data[i].name;
							  $scope.foodList[i].price=response.data[i].price;
						}
					
				});
			}
			
			$scope.addToCart = function(food,quant)
			{
				
				
				  $scope.foodCart.name=food.name;
				  $scope.foodCart.price=food.price;
				  $scope.foodCart.quantity =quant;
				  $scope.foodCart.username= $rootScope.userName;
				var fooddata = angular.toJson($scope.foodCart);
				
				$http.post("http://localhost:8000/SnackBox/api/SnackBoxLogin/addtocart/",fooddata)
				.then(function(response){
					$scope.message=response.data;
					
					
				});
			}
			
			
			
			$scope.fetchCartItems =function()
			{
				var data= angular.toJson($rootScope.userName);
				
				$http.get("http://localhost:8000/SnackBox/api/SnackBoxLogin/cartItems/"+data)
				.then(function(response){
					alert("cart function");
					for(var i = 0 ; i<response.data.length;i++)
						{
							$scope.cartItems[i]={};	 
							$scope.cartItems[i].name=response.data[i].name;
							
							$scope.cartItems[i].price=response.data[i].price;
							$scope.cartItems[i].quantity=response.data[i].quantity;
							$scope.cartItems[i].tPrice=response.data[i].tPrice;
							
						}
					
				});
				
			}
			
			$scope.removeFromCart=function(food)
			{
				$scope.foods.name=  food.name;
				$scope.foods.user=  $rootScope.userName;
				var fooddata = angular.toJson($scope.foods);
				$http.post("http://localhost:8000/SnackBox/api/SnackBoxLogin/delcartItems/",fooddata).
					then(function(response)
					{
						$scope.message = response.data;
						alert($scope.message);
						$route.reload();
					},function(response)
					{
						$scope.message = response.data;
					})
			
			}
			
			
			
		});