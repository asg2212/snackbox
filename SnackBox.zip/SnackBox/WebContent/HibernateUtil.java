
package Dao;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

import Entity.DetailsEntity;

public class HibernateUtil {
	
	private static final SessionFactory sessionfactory ;
	
	static
	{
		try
		{
			Configuration cfg = new AnnotationConfiguration().configure().addAnnotatedClass(DetailsEntity.class);
			ServiceRegistry service = new ServiceRegistryBuilder().applySettings(cfg.getProperties()).buildServiceRegistry();
			sessionfactory = cfg.buildSessionFactory(service);
		}
		catch(Throwable e)
		{
			System.err.println("error"+ e);
			throw new ExceptionInInitializerError(e);
		}
	}
	
	public static SessionFactory getSessionFactory()
	{
		return sessionfactory;
	}
}
