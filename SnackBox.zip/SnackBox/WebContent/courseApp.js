var courseApp= angular.module("courseApp",[]);

courseApp.controller("courseCtrl", function($scope)
		{
	
			alert("hi");
			$scope.name=null;
			$scope.gender=null;
			$scope.contact=null;
			$scope.training= null;
			$scope.level = null;
			$scope.getCourses= function()
			{	
				alert("hihi");
				if ($scope.training == "VCR")
					{
						$scope.courses=[{courseName: "Node.js"}, {courseName: "React.js"}, {courseName: "Cloud computing"}];
						
					}
				else if($scope.training == "OCR")
					{
					$scope.courses=[{courseName: "Spring"}, {courseName: "Python"}, {courseName: "Artificial Intelligence"}];
					
					}
			}
		});

courseApp.directive("eDir",function()
		{
			return{
				restrict: 'C',
				/*scope : {'header' : '=title'},
				template: '<h3 style="color:red"> {{header}} </h3>'*/
				link: function ($scope, element) {
		            element.bind("click", function () {
		                //element.css("border-radius", "10px");
		                element.css("background-color", "orange");
		            });
		        }
			}
		});





courseApp.controller('registerReportCtrl', function($scope){

	$scope.heading="Example for Filters";
	$scope.title="Course Registrations";
	$scope.requests=[
	                 { 	
	                	 username:'Jack',
	                	 courseSelected:'AngularJS',
	                	 levelOfTraining:'Basic',
	                	 dateOfRegistration: new Date(),
	                	 costOfTraining: 18000	                	 
	                 },
	                 {
	                	 username:'Tom',
	                	 courseSelected:'AngularJS',
	                	 levelOfTraining:'Intermediate',
	                	 dateOfRegistration: new Date(),
	                	 costOfTraining: 25000	                	 
	                 },
	                 {
	                	 username:'Alice',
	                	 courseSelected:'AngularJS',
	                	 levelOfTraining:'Advanced',
	                	 dateOfRegistration: new Date(),
	                	 costOfTraining: 35000	                	 
	                 },
	                 {
	                	 username:'Vinu',
	                	 courseSelected:'BackboneJS',
	                	 levelOfTraining:'Basic',
	                	 dateOfRegistration: new Date(),
	                	 costOfTraining: 15000	                	 
	                 },
	                 {
	                	 username:'Niel',
	                	 courseSelected:'BackboneJS',
	                	 levelOfTraining:'Intermediate',
	                	 dateOfRegistration: new Date(),
	                	 costOfTraining: 23000	                	 
	                 },
	                 {
	                	 username:'Jasmine',
	                	 courseSelected:'HTML',
	                	 levelOfTraining:'Basic',
	                	 dateOfRegistration: new Date(),
	                	 costOfTraining: 3000	                	 
	                 },
	                 {
	                	 username:'Daniel',
	                	 courseSelected:'CSS3',
	                	 dateOfRegistration: new Date(),
	                	 levelOfTraining:'Advanced',
	                	 costOfTraining: 10000	                	 
	                 }
	                 ];
	
	 $scope.total= $scope.requests.length;

	 
});




